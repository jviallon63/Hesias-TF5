output "sa_name" {
  description = "Nom du storage account généré"
  value = azurerm_storage_account.tfstate.name
}