resource "azurerm_resource_group" "shared" {
  name     = "rg-tp5-cicd"
  location = "West Europe"
}

resource "azurerm_virtual_network" "vnet" {
  name                = "vnet-tp5"
  location            = azurerm_resource_group.shared.location
  resource_group_name = azurerm_resource_group.shared.name
  address_space       = ["10.0.0.0/16"]
}

resource "azurerm_subnet" "main" {
  for_each             = var.subnets

  name                 = "snet-${each.key}"
  resource_group_name  = azurerm_resource_group.shared.name
  virtual_network_name = azurerm_virtual_network.vnet.name
  address_prefixes     = [each.value.address_prefix]
}